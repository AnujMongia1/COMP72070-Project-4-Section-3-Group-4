using csharp_server;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebSocketSharp;
using WebSocketSharp.Net;
using WebSocketSharp.Server;

namespace csharp_server_tests
{
    [TestClass]
    public class UnitTest1
    {
        private WebSocketServer _server;

        [TestInitialize]
        public void Initialize()
        {
            _server = new WebSocketServer("ws://127.0.0.1:7890");
            _server.AddWebSocketService<Echo>("/Echo");
            _server.AddWebSocketService<EchoAll>("/EchoAll");
            _server.Start();
        }

        [TestMethod]
        public void TestEcho()
        {
            using (var ws = new WebSocket("ws://127.0.0.1:7890/Echo"))
            {
                ws.Connect();
                ws.Send("Hello Echo");
                ws.OnMessage += (sender, e) =>
                {
                    Assert.AreEqual("Hello Echo", e.Data);
                    ws.Close();
                };
            }
        }

        [TestMethod]
        public void TestEchoAll()
        {
            using (var ws = new WebSocket("ws://127.0.0.1:7890/EchoAll"))
            {
                ws.Connect();
                ws.Send("Hello EchoAll");
                ws.OnMessage += (sender, e) =>
                {
                    Assert.AreEqual("Hello EchoAll", e.Data);
                    ws.Close();
                };
            }
        }

        [TestCleanup]
        public void Cleanup()
        {
            _server.Stop();
        }
    }
}