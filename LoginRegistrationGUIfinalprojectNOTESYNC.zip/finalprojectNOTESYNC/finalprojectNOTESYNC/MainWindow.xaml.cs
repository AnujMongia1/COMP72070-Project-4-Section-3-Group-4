﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;


namespace finalprojectNOTESYNC
{
    /// <summary>
    /// Interaction      for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Stack<StrokeCollection> _strokesUndoStack = new Stack<StrokeCollection>();
        private Stack<UIElement> _elementsUndoStack = new Stack<UIElement>();
        private TextBox _textBox = null;
        private string notebooksBasePath = "D:\\ANDROID_DEVELOPMENT";
        public MainWindow()
        {
            InitializeComponent();
            InitializeNoteCanvas();


        }
        private void InitializeNoteCanvas()
        {
            InkCanvasArea.DefaultDrawingAttributes.Color = Colors.White;
            InkCanvasArea.Background = new SolidColorBrush(Colors.Black);
            InkCanvasArea.EditingMode = InkCanvasEditingMode.Ink;
        }


        private void CreateNewNotebook(object sender, RoutedEventArgs e)
        {

            var dialog = new SaveFileDialog();
            dialog.Title = "Create New Notebook";
            dialog.Filter = "NoteSync|*.ns";
            dialog.FileName = "New Notebook";
            if (dialog.ShowDialog() == true)
            {
                string notebookPath = dialog.FileName;
                try
                {

                    Directory.CreateDirectory(notebookPath);


                    Button notebookButton = new Button()
                    {
                        Content = Path.GetFileName(notebookPath),
                        Margin = new Thickness(5),
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        VerticalAlignment = VerticalAlignment.Center,
                        Padding = new Thickness(5),
                        Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x3E, 0x44, 0x4D)),
                        Foreground = new SolidColorBrush(Colors.White),
                        BorderThickness = new Thickness(0)

                    };
                    notebookButton.Click += NotebookButton_Click;
                    NotebooksPanel.Children.Add(notebookButton);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating notebook: " + ex.Message);
                }
            }
        }

        private string currentNotebookPath;

        private void NotebookButton_Click(object sender, RoutedEventArgs e)
        {
            // Assuming the button's content is the notebook name
            var notebookName = (sender as Button)?.Content.ToString();
            currentNotebookPath = Path.Combine(notebooksBasePath, notebookName);

            // Display the canvas sidebar for the selected notebook
            CanvasStackPanel.Visibility = Visibility.Visible;
            //LoadCanvasButtons(currentNotebookPath); // Load existing canvases for the notebook
        }

        private void AddNewCanvasButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a canvas file in the current notebook folder
            string canvasFileName = "Canvas " + Guid.NewGuid() + ".ink";
            string canvasFilePath = Path.Combine(currentNotebookPath, canvasFileName);
            File.Create(canvasFilePath).Dispose(); // Immediately dispose to release the file

            // Add a button to represent the canvas in the UI
            Button canvasButton = new Button
            {
                Content = Path.GetFileNameWithoutExtension(canvasFilePath),
                Tag = canvasFilePath,
                // Set other properties as needed
            };
            canvasButton.Click += CanvasButton_Click; // Add event handler
            CanvasStackPanel.Children.Add(canvasButton);

            // Optionally, open the canvas for editing
            DisplayCanvas(canvasFilePath);
        }


        private void CanvasButton_Click(object sender, RoutedEventArgs e)
        {
            // Retrieve the canvas file path from the button's Tag property
            var canvasFilePath = (sender as Button)?.Tag.ToString();
            if (!string.IsNullOrEmpty(canvasFilePath))
            {
                DisplayCanvas(canvasFilePath);
            }
        }

        private void LoadCanvasButtons(string notebookPath)
        {
            // Logic to load canvas buttons for the selected notebook
            // This would typically list files in the notebookPath directory and create buttons for them
        }

        private void DisplayCanvas(string canvasFilePath)
        {
            // Make the InkCanvas visible if it's not already
            InkCanvasArea.Visibility = Visibility.Visible;

            // Load the canvas file and display it in the InkCanvas control
            // This is where you load the content into the InkCanvas
            // For example, if you're using ink strokes, deserialize them from the file and display them
        }

        

        private void PenButton_Click(object sender, RoutedEventArgs e)
        {
            InkCanvasArea.EditingMode = InkCanvasEditingMode.Ink;
            RemoveTextBox();
        }

        private void EraserButton_Click(object sender, RoutedEventArgs e)
        {
            InkCanvasArea.EditingMode = InkCanvasEditingMode.EraseByPoint;
            RemoveTextBox();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Z && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            {
                e.Handled = true;
                UndoLastAction();
            }
            else if (e.Key == Key.V && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            {
                e.Handled = true;
                PasteImageFromClipboard();
            }
            else if (e.Key != Key.LeftCtrl && e.Key != Key.RightCtrl && e.Key != Key.Enter && e.Key != Key.Back)
            {
                CreateOrFocusTextBox(e);
            }
        }

        private void UndoLastAction()
        {
            if (_strokesUndoStack.Count > 0)
            {
                InkCanvasArea.Strokes = _strokesUndoStack.Pop();
            }
            else if (_elementsUndoStack.Count > 0)
            {
                var element = _elementsUndoStack.Pop();
                InkCanvasArea.Children.Remove(element);
            }
        }

        private void PasteImageFromClipboard()
        {
            if (Clipboard.ContainsImage())
            {
                BitmapSource image = Clipboard.GetImage();
                Image img = new Image { Source = image };
                Point position = Mouse.GetPosition(InkCanvasArea);
                InkCanvas.SetLeft(img, position.X);
                InkCanvas.SetTop(img, position.Y);
                InkCanvasArea.Children.Add(img);
                _elementsUndoStack.Push(img);
            }
        }

        private void CreateOrFocusTextBox(KeyEventArgs e)
        {
            Point position = Mouse.GetPosition(InkCanvasArea);
            if (_textBox == null)
            {
                _textBox = new TextBox
                {
                    Width = double.NaN,
                    Height = double.NaN,
                    Background = new SolidColorBrush(Colors.Transparent),
                    Foreground = new SolidColorBrush(Colors.White),
                    BorderThickness = new Thickness(0),
                    TextWrapping = TextWrapping.Wrap
                };
                InkCanvas.SetLeft(_textBox, position.X);
                InkCanvas.SetTop(_textBox, position.Y);
                InkCanvasArea.Children.Add(_textBox);
                _elementsUndoStack.Push(_textBox);
            }
            _textBox.Focus();
            if (!char.IsControl((char)e.Key) && e.Key != Key.Enter && e.Key != Key.Back)
            {
                _textBox.Text += e.Key.ToString();
            }
        }

        private void RemoveTextBox()
        {
            if (_textBox != null)
            {
                InkCanvasArea.Children.Remove(_textBox);
                _textBox = null;
            }
        }
    }
}