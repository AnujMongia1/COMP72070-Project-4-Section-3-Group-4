﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using WebSocketSharp;

namespace PROJ_4_FINAL_GUI
{
    public partial class MainWindow : Window
    {
        private string selectedNotebookPath = "";
        private string selectedCanvasFilePath = "";
        private InkCanvas inkCanvas;
        
        private WebSocket ws;
        public MainWindow()
        {
            InitializeComponent();
            InitializeWebSocket();
            inkCanvas = new InkCanvas();
            

        }

        private void InitializeWebSocket()
        {
            ws = new WebSocket("ws://127.0.0.1:7890/EchoAll");
            ws.OnMessage += Ws_OnMessage;
            ws.Connect();
            //ws.Send("connected");
        }

        private void Ws_OnMessage(object sender, MessageEventArgs e)
        {
            try
            {

                dynamic jsonPacket = JsonConvert.DeserializeObject(e.Data);


                PacketType type = (PacketType)jsonPacket.PacketHeader.Type;
                int sequenceNumber = jsonPacket.PacketHeader.SequenceNumber;
                DateTime timeStamp = jsonPacket.PacketHeader.TimeStamp;


                var strokesData = new List<List<Point>>();
                if (type == PacketType.DrawingData)
                {

                    var dataToken = jsonPacket.PacketBody.Data;

 
                    if (dataToken is JArray strokesArray)
                    {
                        foreach (var strokePoints in strokesArray)
                        {
                            var points = new List<Point>();

                            foreach (var pointToken in strokePoints)
                            {
                                var pointString = pointToken.ToString();
                                var pointParts = pointString.Split(',');
                                if (pointParts.Length == 2 && double.TryParse(pointParts[0], out double x) && double.TryParse(pointParts[1], out double y))
                                {
                                    points.Add(new Point(x, y));
                                }
                            }
                            strokesData.Add(points);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid data format for DrawingData packet.");
                    }
                }

                Packet receivedPacket = new Packet(type, sequenceNumber, timeStamp, strokesData);

                switch (receivedPacket.PacketHeader.Type)
                {
                    case PacketType.DrawingData:
                        HandleDrawingDataPacket(receivedPacket);
                        break;

                    default:
                        Console.WriteLine("Unknown packet type received.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error processing packet: " + ex.Message);
            }
        }

        private void HandleDrawingDataPacket(Packet packet)
        {

            var strokesData = (List<List<Point>>)packet.PacketBody.Data;

            write_strokes_data_to_canvas(strokesData);
        }

        private void write_strokes_data_to_canvas(List<List<Point>> strokesData)
        {
            Dispatcher.Invoke(() =>
            {
                try
                {
                    foreach (List<Point> strokePoints in strokesData)
                    {
                        StylusPointCollection points = new StylusPointCollection();
                        foreach (Point point in strokePoints)
                        {
                            points.Add(new StylusPoint(point.X, point.Y));
                        }
                        Stroke newStroke = new Stroke(points);
                        inkCanvas.Strokes.Add(newStroke);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            });
        }

        private void InkCanvas_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            var strokesData = new List<List<Point>>();
            foreach (var stroke in inkCanvas.Strokes)
            {
                var strokePoints = new List<Point>();
                foreach (var stylusPoint in stroke.StylusPoints)
                {
                    strokePoints.Add((Point)stylusPoint);
                }
                strokesData.Add(strokePoints);
            }

                            /*            string jsonStrokes = JsonConvert.SerializeObject(strokesData, Newtonsoft.Json.Formatting.Indented);
                                        ws.Send(jsonStrokes)*/;


            var packet = new Packet(PacketType.DrawingData, 1, DateTime.Now, strokesData);
            var serializedPacket = packet.Serialize();
            ws.Send(serializedPacket);


            WritePacketToFile(System.Text.Encoding.ASCII.GetBytes(serializedPacket), "packet.txt");

        }

        private void WritePacketToFile(byte[] packetContent, string filePath)
        {
            try
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
                {
                    fileStream.Write(packetContent, 0, packetContent.Length);
                }
                Console.WriteLine("Packet written to file successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error writing packet to file: " + ex.Message);
            }
        }

        private void CreateNewNotebook(object sender, RoutedEventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Title = "Create New Notebook";
            dialog.Filter = "NoteSync Files|.ns|All Files|.*";
            dialog.FileName = "New Notebook.ns";
            if (dialog.ShowDialog() == true)
            {
                selectedNotebookPath = dialog.FileName;
                try
                {
                    Directory.CreateDirectory(selectedNotebookPath);
                    Button notebookButton = new Button()
                    {
                        Content = Path.GetFileName(selectedNotebookPath),
                        Tag = selectedNotebookPath,
                        Margin = new Thickness(5),
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        VerticalAlignment = VerticalAlignment.Center,
                        Padding = new Thickness(5),
                        Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x3E, 0x44, 0x4D)),
                        Foreground = Brushes.White,
                        BorderThickness = new Thickness(0)
                    };
                    notebookButton.Click += NotebookButton_Click;
                    NotebooksPanel.Children.Add(notebookButton);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating notebook: " + ex.Message);
                }
            }
        }

        private void NotebookButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                selectedNotebookPath = button.Tag.ToString();
                CanvasStackPanel.Visibility = Visibility.Visible;
            }
        }

        private void AddNewCanvas(string notebookPath)
        {

            var canvasDialog = new CanvasNameDialog();
            if (canvasDialog.ShowDialog() == true)
            {
                string canvasName = canvasDialog.CanvasName;
                string canvasFileName = canvasName + ".json";
                selectedCanvasFilePath = Path.Combine(notebookPath, canvasFileName);

                try
                {
                    File.Create(selectedCanvasFilePath).Close();
                    Console.WriteLine("Canvas file created at: " + selectedCanvasFilePath);

                    inkCanvas = new InkCanvas();
                    inkCanvas.StrokeCollected += InkCanvas_StrokeCollected;
                    InkCanvasContainer.Children.Add(inkCanvas);

                    Button canvasButton = new Button
                    {
                        Content = canvasName,
                        Tag = selectedCanvasFilePath,
                        Margin = new Thickness(5),
                        Background = Brushes.LightGray
                    };
                    canvasButton.Click += CanvasButton_Click;
                    CanvasStackPanel.Children.Add(canvasButton);

                    Console.WriteLine("Canvas created at: " + selectedCanvasFilePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating canvas: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Canvas creation canceled.");
            }
        }

        private void AddNewCanvasClick(object sender, RoutedEventArgs e)
        {
            AddNewCanvas(selectedNotebookPath);
        }

        private void CanvasButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                if (inkCanvas.Parent != InkCanvasContainer)
                {
                    InkCanvasContainer.Children.Add(inkCanvas);
                }
                string canvasFilePath = button.Tag.ToString();
                DisplayCanvas(canvasFilePath);
            }
        }




        private void DisplayCanvas(string canvasFilePath)
        {
            try
            {
                if (inkCanvas != null)
                {
                    if (File.Exists(canvasFilePath))
                    {
                        string json = File.ReadAllText(canvasFilePath);

                        inkCanvas.Strokes.Clear();

                        List<List<Point>> strokesData = JsonConvert.DeserializeObject<List<List<Point>>>(json);

                        foreach (List<Point> strokePoints in strokesData)
                        {
                            StylusPointCollection points = new StylusPointCollection();
                            foreach (Point point in strokePoints)
                            {
                                points.Add(new StylusPoint(point.X, point.Y));
                            }
                            Stroke newStroke = new Stroke(points);
                            inkCanvas.Strokes.Add(newStroke);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Canvas file does not exist: " + canvasFilePath);
                    }
                }
                else
                {
                    MessageBox.Show("InkCanvas is not initialized.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading canvas: " + ex.Message);
            }
        }


        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Hello world!");

            SaveStrokesToFile(inkCanvas, selectedCanvasFilePath);

        }

        private void SaveStrokesToFile(InkCanvas inkCanvas, string filePath)
        {
            var strokesData = new List<List<Point>>();
            foreach (var stroke in inkCanvas.Strokes)
            {
                var strokePoints = new List<Point>();
                foreach (var stylusPoint in stroke.StylusPoints)
                {
                    strokePoints.Add(new Point(stylusPoint.X, stylusPoint.Y));
                }
                strokesData.Add(strokePoints);
            }

            string jsonStrokes = JsonConvert.SerializeObject(strokesData, Newtonsoft.Json.Formatting.Indented);

            File.WriteAllText(filePath, jsonStrokes);
        }

        private void OpenNotebookFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.Title = "Select Notebook Folder";
            dialog.Filter = "Folder|.";
            dialog.ValidateNames = false;
            dialog.CheckFileExists = false;
            dialog.CheckPathExists = true;
            dialog.FileName = "Select Folder";

            if (dialog.ShowDialog() == true)
            {
                string notebookFolderPath = Path.GetDirectoryName(dialog.FileName);
                try
                {
                    Button notebookButton = new Button()
                    {
                        Content = Path.GetFileName(notebookFolderPath),
                        Tag = notebookFolderPath,
                        Margin = new Thickness(5),
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        VerticalAlignment = VerticalAlignment.Center,
                        Padding = new Thickness(5),
                        Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x3E, 0x44, 0x4D)),
                        Foreground = Brushes.White,
                        BorderThickness = new Thickness(0)
                    };
                    notebookButton.Click += NotebookButton_Click;
                    NotebooksPanel.Children.Add(notebookButton);

                    LoadCanvases(notebookFolderPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening notebook folder: " + ex.Message);
                }
            }
        }



        private void LoadCanvases(string notebookFolderPath)
        {
            

            string[] canvasFiles = Directory.GetFiles(notebookFolderPath, "*.json");

            foreach (string canvasFile in canvasFiles)
            {
                selectedCanvasFilePath = Path.Combine(notebookFolderPath, canvasFile);
                Button canvasButton = new Button
                {
                    Content = Path.GetFileNameWithoutExtension(canvasFile),
                    Tag = selectedCanvasFilePath,
                    Margin = new Thickness(5),
                    Background = Brushes.LightGray
                };

                canvasButton.Click += CanvasButton_Click;
                CanvasStackPanel.Children.Add(canvasButton);
            }
        }




    }

    public enum PacketType
    {
        EstablishConnection,
        DrawingData,
        AddImage,
        AddText,
        CreateSession,
        JoinSession,
        Login,
        CloseConnection,
    }

    public class Packet
    {
        public Header PacketHeader { get; set; }
        public Body PacketBody { get; set; }

        public Packet(PacketType type, int sequenceNumber, DateTime timeStamp, object bodyData)
        {
            PacketHeader = new Header { Type = type, SequenceNumber = sequenceNumber, TimeStamp = timeStamp };
            PacketBody = new Body { Data = bodyData };
        }

        public string Serialize()
        {
            string json = JsonConvert.SerializeObject(this);
            return json;
            //return System.Text.Encoding.ASCII.GetBytes(json);
        }

        public static Packet Deserialize(byte[] data)
        {
            string json = System.Text.Encoding.ASCII.GetString(data);
            return JsonConvert.DeserializeObject<Packet>(json);
        }

        public class Header
        {
            public PacketType Type { get; set; }
            public int SequenceNumber { get; set; }
            public DateTime TimeStamp { get; set; }
        }

        public class Body
        {
            public object Data { get; set; }
        }
    }

}


